# fbcmd4j

Instalacion:

Importar proyecto a eclipse

Exportar Jar: 

Clic en export, runnable jar file 
Seleccionar la clase de main como launch configuration 
Seleccionar carpeta donde se guardara
Terminar
 
Ejecutar Jar:

Abrir cmd con permisos de administrador
Acceder a la ruta del archivo .jar
Ejecutar .jar con el comando: java -jar fbcmd4j.jar

 
Uso:

Opcion 1: Acceder al newsfeed
Opcion 2: Publicar en wall
Opcion 3: Publicar un estado
Opcion 4: Publicar un link
Opcion 5: Finalizar el programa

Creditos:

Código base desarrollado por:

Jose Manuel Lopez Lujan, MIT
https://github.com/jm66/CS13303

Desarrollado por:

Josué Iván Rodríguez Arámbula

Licencia:

El código está bajo la licencia MIT. Consulte el archivo LICENSE para más información.
